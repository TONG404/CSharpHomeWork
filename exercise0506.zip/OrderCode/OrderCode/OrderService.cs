﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace OrderCode
{
    public class OrderService
    {
        public static List<Order> orderList = new List<Order>();

        public static void AddOrder(Order o)
        {
            foreach (Order od in orderList)            //判断是否重复
                if (od.Equals(o))
                    throw new Exception("该订单不存在！");
            orderList.Add(o);
        }

        //（按照订单号）查询订单
        public static string Find1(string ID)
        {
            var o = from order in orderList where order.ID == ID select order;
            Order od = o.First();
            if (od!=null)
                return od.ToString();
            else
                throw new Exception("该订单不存在！");
        }

        //（按商品名称）查询订单
        public static string Find2(string Name)
        {
            string info= "";
            foreach (Order order in orderList)
            {
                var o = from ord in order.orderItemList where ord.Name == Name select order;
                Order od = o.FirstOrDefault();
                if (od != null)
                    info += od.ToString();
            }
            if (info == "")
                throw new Exception("该订单不存在！");
            return info;
        }

        //(按客户)查询订单
        public static string Find3(string customerName)
        {
            
            var o = from order in orderList where order.customer.name == customerName select order;
            Order od = o.First();
            if (od != null)
                return od.ToString();
            else
                throw new Exception("该订单不存在!");
        }
        public static string Find4(string customerID)
        {
            
            var o = from order in orderList where order.customer.IDNumber == customerID select order;
            Order od = o.First();
            if (od != null)
                return od.ToString();
            else
                throw new Exception("该订单不存在！");
        }
        //（根据订单号）删除订单
        public static void DelOrder(string ID)
        {
            Order del = null;
            
            foreach (Order od in orderList)//查找该订单
                if (od.ID == ID)
                    del = od;
            if (del != null)
                orderList.Remove(del);
        }

        //（根据订单号）修改订单
        public static void Change(string ID, Order newOrder)
        {
            
            var o = from order in orderList where order.ID == ID select order;
            Order od = o.First();
            orderList.Remove(od);
            orderList.Add(newOrder);
        }


        //(照订单号)排序
        public static void Sort()
        {
            
            var orders = from order in orderList orderby order.ID select order;
            orderList = orders.ToList();
        }

        //序列化
        public static void Export()
        {
            try
            {
                
                XmlSerializer xs = new XmlSerializer(typeof(List<Order>));
                using (FileStream fs = new FileStream("text.xml", FileMode.Create))  // 写到XML
                {
                    xs.Serialize(fs,orderList);
                }
                Console.WriteLine(File.ReadAllText("text.xml"));
            }
            catch(FileNotFoundException)
            {
                Console.WriteLine("文件不存在！");
            }
        }
        //反序列化
        public static void Import()
        {
            if (!File.Exists(("text.xml")))
                Console.WriteLine("文件不存在！");
            else
            {
                
                XmlSerializer xs = new XmlSerializer(typeof(List<Order>));
                using (FileStream fs = new FileStream("text.xml", FileMode.Open))
                {
                    List<Order> newList = (List<Order>)xs.Deserialize(fs);
                    foreach (Order o in newList)
                        orderList.Add(o);
                }
            }
        }
    }
}
