﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Test
    {
        [TestInitialize]
        public void TestInitialize()//每个测试执行之前都已经添加了两个订单，方便测试
        {
            OrderService.orderList.Clear();
            OrderService.AddOrder(new Order(
                "001",
                "湖北",
                new Customer("张三", "333"),
                new List<OrderItem>() { new OrderItem(new Commodity("pen", 5.00), 5), new OrderItem(new Commodity("pencil", 2.5), 2) }
                ));
            OrderService.AddOrder(new Order(
                "002",
                "湖南",
                new Customer("李四", "444"),
                new List<OrderItem>() { new OrderItem(new Commodity("pen", 5.00), 5) }
                ));
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
