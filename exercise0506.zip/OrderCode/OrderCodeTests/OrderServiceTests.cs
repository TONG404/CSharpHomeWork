﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderCode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace OrderCode.Tests
{
    [TestClass()]
    public class OrderServiceTests
    {
        //初始化
        [TestInitialize]
        public void TestInitialize()
        {
            OrderService.orderList.Clear();
            OrderService.AddOrder(new Order(
                    "000001",
                    new Customer("李雷", "20182302110"),
                new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
                ));
            OrderService.AddOrder(new Order(
                    "000002",
                    new Customer("韩梅梅", "2018302111"),
                    new List<OrderItem>() { new OrderItem("scarf", 1, 50.00) }
                    ));
        }

        //测试
        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void AddOrderTest1()  //测试添加相同订单
        {
            OrderService.AddOrder(new Order(
                "000001",
                new Customer("李雷", "20182302110"),
                new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
                ));
            OrderService.AddOrder(new Order(
                "000001",
                new Customer("李雷", "20182302110"),
                new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
                ));
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void AddOrderTest2()  //测试添加空订单
        {
            OrderService.AddOrder(null);
        }

        [TestMethod()]
        public void AddOrderTest3()//测试--正确添加订单
        {
            int num1 = OrderService.orderList.Count;
            OrderService.AddOrder(new Order());
            int num2 = OrderService.orderList.Count;
            Assert.AreEqual(num1 + 1, num2);
        }


        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void Find1Test1()         //测试正确查询订单
        {
            string orderInfo = OrderService.Find1("000001");
            Assert.AreEqual(orderInfo, new Order(
                "000001",
                new Customer("李雷", "2018302110"),
                new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
                ).ToString()
                );
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void Find1Test2()         //测试查询不存在的订单
        {
            OrderService.Find1("123");
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void Find2Test1()               //测试正确查询订单
        {
            string orderInfo = OrderService.Find1("socks");
            Assert.AreEqual(orderInfo, new Order(
                "000001",
                new Customer("李雷", "2018302110"),
                new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
                ).ToString()
                );
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void Find2Test2()       //测试查询不存在的订单
        {
            OrderService.Find2("skirt");
        }

        [TestMethod()]
        public void Find3Test1()        //测试正确查询订单 
        {
            string orderInfo = OrderService.Find3("李雷");
            Assert.AreEqual(orderInfo, new Order(
    "000001",
    new Customer("李雷", "2018302110"),
    new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
    ).ToString()
    );
        }

        [TestMethod()]
        public void Find3Test2()        //测试查询不存在的订单
        {
            OrderService.Find3("Andy");
        }

        [TestMethod()]
        public void Find4Test1()          //测试正确查询订单
        {
            string orderInfo = OrderService.Find4("2018302110");
            Assert.AreEqual(orderInfo, new Order(
"000001",
new Customer("李雷", "2018302110"),
new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
).ToString()
);
        }
        [TestMethod()]
        public void Find4Test2()        //测试查询不存在的订单
        {
            OrderService.Find4("1111111111");
        }


        [TestMethod()]
        public void DelOrderTest1()        //测试正确删除订单
        {
            OrderService.DelOrder("000001");
            Assert.AreEqual(OrderService.orderList.Count, 1);
            Assert.AreEqual(OrderService.orderList[0].ToString(),new Order(
                "000002",
                new Customer("韩梅梅", "2018302111"),
                new List<OrderItem>() { new OrderItem("scarf", 1, 50.00) }
                ));
        }
        [TestMethod()]
        public void DelOrderTest2()      //测试删除不存在的订单
        {
            string oldInfo = "", newInfo = "";
            foreach (Order o in OrderService.orderList)
                oldInfo += o.ToString();
            OrderService.DelOrder("003");
            foreach (Order o in OrderService.orderList)
                newInfo += o.ToString();
            Assert.AreEqual(oldInfo, newInfo);
        }

        [TestMethod()]
        public void ChangeTest1()   //测试正确修改订单
        {
            string inFactInfo = "", expectInfo = "";
            OrderService.Change("000001", new Order());
            foreach (Order o in OrderService.orderList)
                inFactInfo += o.ToString();
            expectInfo = OrderService.Find1("000002") + new Order().ToString();
            Assert.AreEqual(inFactInfo, expectInfo);
        }

        [TestMethod()]
        public void ChangeTest2()      //测试错误修改订单
        {
            OrderService.Change("111111", new Order());
        }

        [TestMethod()]
        public void SortTest1()  //测试正确排序
        {
            string inFactInfo = "", expectInfo = "";
            OrderService.Sort();
            foreach (Order o in OrderService.orderList)
                inFactInfo += o.ToString();
            expectInfo = new Order(
                "000001",
                new Customer("李雷", "20182302110"),
                new List<OrderItem>() { new OrderItem("socks", 2, 5.00), new OrderItem("pencil", 2, 2.5) }
                ).ToString()
                +
                new Order(
                "000002",
                new Customer("韩梅梅", "2018302111"),
                new List<OrderItem>() { new OrderItem("scarf", 1, 50.00) }
                ).ToString();
            Assert.AreEqual(inFactInfo, expectInfo);
        }

        [TestMethod()]
        public void SortTest2()      //测试排序不存在的订单
        {
            OrderService.orderList.Clear();
            OrderService.Sort();
            Assert.AreEqual(0, OrderService.orderList.Count);
        }

        [TestMethod()]
        public void ExportTest1()   //测试正确序列化
        {
            Assert.Fail();
        }

    }
}