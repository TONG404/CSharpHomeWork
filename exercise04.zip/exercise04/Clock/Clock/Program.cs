﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Clock
{
    public delegate void ClockTick(object sender,DateTime dateTime);
    public delegate void ClockAlarm(object sender, DateTime dateTime);

    public class Clock
    {
        public event ClockTick Tick;
        public event ClockAlarm Alarm;

        public void Switch()
        {
            Console.WriteLine("请选择打开或者关闭闹钟：0.关闭  1.打开");
            int state = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("显示当前时间：" + DateTime.Now.ToString("HH:mm:ss"));
            if (state == 1)
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine("嘀嗒~嘀嗒~");
                    Thread.Sleep(1000);
                }
            }
        }
        public string clockRun(int h,int m,int s)
        {
            if(h < 24)
            {
                if (m < 60)
                {
                    if (s< 60)
                        s = s + 1;
                    else
                    {
                        m = m + 1;
                        s = 0;
                    }
                }
                else
                {
                    h = h + 1;
                    m = 0;
                }
            }
            else
                h = 0;
            string time = h + ":" + m + ":" + s;
            return time;
        }
        public string nowTime()
        {
            int hour0 = Convert.ToInt32(DateTime.Now.ToString("HH"));
            int minute0 = Convert.ToInt32(DateTime.Now.ToString("mm"));
            int second0 = Convert.ToInt32(DateTime.Now.ToString("ss"));
            string nowtime = this.clockRun(hour0, minute0, second0);
            return nowtime;
        }
        //设置闹钟时间
        public string setTime()
        {
            Console.WriteLine("请设定闹钟时间：（XX时XX分）");
            int hour= Convert.ToInt32(Console.ReadLine());
            int minute= Convert.ToInt32(Console.ReadLine());
            string alarm =Convert.ToString( hour +":"+minute);
            return alarm;
        }
        public void Alarm(object sender,DateTime dateTime)
        {
            string alarm = this.setTime();
            string time = DateTime.Now.ToString("HH:mm");
            if(String.Equals(alarm, time)){
                Console.WriteLine("叮铃铃~叮铃铃~");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Clock c = new Clock();
                c.Switch();
            string alarm = c.setTime();
            Console.WriteLine(alarm);
            Console.ReadKey();
        }
    }
}
